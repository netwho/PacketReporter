# PacketReporter v0.2.4 Release Notes

## 🎯 Key Improvements

### Enhanced TLS/SSL Detection
- **Completely rewritten TLS version detection** for improved accuracy
- Now correctly identifies **TLS 1.3** using `supported_versions` extension (RFC 8446) and cipher suite detection
- **Fixed false TLS 1.2 reporting** for TLS 1.3 connections
- Only counts handshake packets to avoid false positives from application data
- Improved **QUIC protocol detection** via UDP port 443

### Better User Experience
- **Streamlined dependency reporting** - Only shows messages when dependencies are missing
- **Improved chart display** - TLS version labels positioned at end of bars with white text for better visibility
- Chart subtitle now clearly indicates "Values represent the number of observed handshakes"

### Code Quality
- Removed all debug code for cleaner operation
- Enhanced error handling and dependency checking

## 📋 Technical Details

- **TLS Detection Priority**: `supported_versions` extension → cipher suite (0x1301-0x1305) → protocol string matching → handshake.version
- **Removed misleading `record.version` fallback** (TLS 1.3 uses 0x0303 for compatibility, causing false TLS 1.2 detections)
- **Dependency checks** now prevent PDF export if required tools are missing, with clear error messages

## 🔧 Requirements

- Wireshark 4.0 or later
- For PDF export: `rsvg-convert` (recommended) or `inkscape`/`imagemagick`
- For multi-page PDFs: `pdfunite` (recommended) or `pdftk`

## 📦 Installation

See [README.md](README.md) for platform-specific installation instructions.

---

**Full changelog**: See [CHANGELOG.md](CHANGELOG.md) for complete details.

