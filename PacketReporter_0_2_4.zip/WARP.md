# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

PacketReporter is a comprehensive Wireshark plugin for generating network analysis reports with visualizations and PDF export. The project is implemented as a single-file Lua plugin (~2,580 lines) that integrates directly into Wireshark 4.0+.

**Key characteristics:**
- Pure Lua 5.2+ implementation with no external dependencies
- Single-file architecture: `packet_reporter.lua` contains all functionality
- SVG-based chart generation with multi-converter PDF export support
- Wireshark Listener API (taps) for efficient packet processing
- Cross-platform: macOS, Linux, Windows

## Core Architecture

### Single-File Design Pattern

The entire plugin is contained in `packet_reporter.lua` with the following organization:

1. **Paper Size Configuration** (lines 20-27): A4 and Legal format definitions
2. **Field Extractors** (lines 32-112): Wireshark field definitions for L2-L7 protocols
3. **Utility Functions** (lines 115-221): String formatting, file I/O, command detection
4. **Cover Page System** (lines 223-347): Logo embedding, TOC generation
5. **Converter Detection** (lines 349-390): Multi-tool PDF export support
6. **Chart Generators**: Bar charts, pie charts with SVG output
7. **Data Collection Functions**: Use Wireshark Listener API (taps) pattern
8. **Report Generators**: Summary, Detailed (A4/Legal), optional Communication Matrix
9. **Menu Registration** (lines 2532-2575): Wireshark Tools menu integration

### Data Collection Pattern

All statistics collection follows this Wireshark Listener API pattern:

```lua
local tap = Listener.new("frame", nil)  -- or "dns", "http", "tcp", etc.

function tap.packet(pinfo, tvb)
  -- Extract fields using Field extractors
  -- Aggregate into local tables/dictionaries
end

retap_packets()  -- Process all packets with current filter
tap:remove()     -- Clean up listener
return stats     -- Return aggregated data
```

This pattern is used consistently throughout for efficiency and filter compatibility.

### Field Extraction Safety

All field extractions use safe patterns with pcall() for optional fields:

```lua
local f_field = F("protocol.field")  -- Required field
pcall(function() f_optional = F("protocol.optional") end)  -- Optional field
```

Helper functions `f2s()` and `f2n()` safely convert field values with error handling.

## Development Commands

### Installation & Testing

**Install plugin locally:**
```bash
# Copy to Wireshark plugin directory
cp packet_reporter.lua ~/.local/lib/wireshark/plugins/
chmod 644 ~/.local/lib/wireshark/plugins/packet_reporter.lua

# Or use installer (recommended)
./install.sh                                    # Auto-detect OS
./installers/macos/install.sh                   # macOS specific
./installers/linux/install.sh                   # Linux specific
./installers/windows/install.ps1                # Windows (PowerShell)
```

**Test with Wireshark:**
1. Restart Wireshark after any plugin changes
2. Check `Help → About Wireshark → Folders` to verify plugin directory
3. Test with Tools → PacketReporter menu items
4. Check Wireshark Lua console for errors (View → Internals → Lua)

**Verify dependencies:**
```bash
# Check for PDF converters
command -v rsvg-convert  # Preferred
command -v inkscape      # Alternative
command -v magick        # Alternative

# Check for PDF combiners
command -v pdfunite      # Preferred
command -v pdftk         # Alternative
```

**Install dependencies:**
```bash
# macOS
brew install librsvg poppler

# Linux (Debian/Ubuntu)
sudo apt install librsvg2-bin poppler-utils

# Linux (Fedora/RHEL)
sudo dnf install librsvg2-tools poppler-utils
```

### Development Workflow

**Iterative development cycle:**
1. Edit `packet_reporter.lua`
2. Copy to plugin directory: `cp packet_reporter.lua ~/.local/lib/wireshark/plugins/`
3. Restart Wireshark
4. Test with sample PCAP files from https://wiki.wireshark.org/SampleCaptures
5. Check Lua console for errors

**Test with different scenarios:**
- Empty capture files (should show "No data" messages)
- Small captures (< 1000 packets)
- Large captures (> 10,000 packets)
- Various protocols: HTTP, DNS, TCP, UDP, TLS
- With display filters applied

## Code Style & Conventions

### Lua Style (Strict Adherence Required)

- **2-space indentation** (not tabs)
- **snake_case** for functions and variables
- **UPPER_CASE** for constants
- **Local variables** everywhere for performance
- **pcall()** for safe field extraction
- **Table pre-allocation** where possible

### Function Organization

Functions follow a clear pattern:
```lua
local function collect_stats()
  local stats = {}  -- Pre-allocate return structure
  local tap = Listener.new("protocol", nil)
  
  function tap.packet(pinfo, tvb)
    -- Extract and aggregate
  end
  
  retap_packets()
  tap:remove()
  return stats
end
```

### SVG Generation Pattern

All chart functions use this consistent pattern:
```lua
local function generate_chart(data, title, x, y, width, height, show_legend)
  local out = {}
  local function add(s) table.insert(out, s) end
  
  -- SVG header if standalone
  add('<?xml version="1.0" encoding="UTF-8"?>\\n')
  add('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\\n')
  
  -- Generate chart elements
  add('<g>...</g>\\n')
  
  return table.concat(out)  -- Efficient string concatenation
end
```

## Important Constraints & Limitations

### Wireshark Lua API Limitations

**Cannot implement (due to API constraints):**
- GeoIP country lookups (requires external C libraries)
- JA3/JA3S TLS fingerprinting (needs crypto libraries)
- Deep packet payload inspection
- ARP spoofing detection (limited dissector access)
- Custom protocol dissectors (requires C)

**Can implement (within Lua capabilities):**
- Protocol statistics using existing dissectors
- Traffic pattern analysis
- Port/service identification
- DNS/HTTP/TLS metadata extraction
- Chart generation and visualization

### Performance Considerations

- **Linear scaling** with packet count
- Display filters reduce processing proportionally
- Multiple taps in detailed reports increase processing time
- Large captures (100K+ packets) may take 30-60 seconds
- SVG generation is fast; PDF conversion is the bottleneck

## Configuration & Customization

### User Configuration Files

Location: `~/.packet_reporter/`

**Logo customization:**
- File: `~/.packet_reporter/Logo.png`
- Used in detailed report cover pages
- Embedded as base64 data URI in SVG
- Fallback to text logo if not present

**Report description:**
- File: `~/.packet_reporter/packet_reporter.txt`
- Three lines maximum
- Example format:
  ```
  Customer: Acme Corporation
  Segment: Production Network
  Notes: Quarterly Security Audit
  ```

### Output Location

Generated reports are saved to:
`~/Documents/PacketReporter Reports/`

Format: `PacketReport-YYYYMMDD-HHMMSS.pdf`

## Report Types & Sections

### 1. Summary Report
- Quick overview (1-2 pages)
- Basic statistics, top IPs, protocol distribution, top ports
- Single tap pass through packets

### 2. Detailed Report (A4 or Legal)
- Comprehensive analysis (3-8 pages)
- 12 major sections including cover page with TOC
- Multiple tap passes: frame, DNS, HTTP, TLS, TCP, IP, MAC
- Sections: PCAP summary, Top IPs, Protocol distribution, IP matrix, Ports, Protocol hierarchy, DNS analysis, TLS/SSL analysis, HTTP analysis, MAC layer, IP layer, TCP analysis

### 3. Communication Matrix (Optional)
- Requires separate `comm_matrix_table_view.lua` plugin
- Circular visualization of network communications
- Auto-detected and added to menu if available

## PDF Export Architecture

### Multi-Converter Support (Priority Order)

1. **rsvg-convert** (librsvg) - Fastest, best quality ✅
2. **Inkscape** - Good quality, slower
3. **ImageMagick** (magick/convert) - Fallback

### Multi-Page PDF Generation

Process for reports exceeding one page:
1. Calculate total content height in pixels
2. Split SVG content into page-sized chunks
3. Generate individual PDF per page using converter
4. Combine with `pdfunite` (preferred) or `pdftk`
5. Save to `~/Documents/PacketReporter Reports/`

Detection and fallback logic is in `detect_converters()` function.

## Adding New Features

### Adding a New Protocol Analysis Section

1. **Create field extractors** (top of file, after line 112):
   ```lua
   local f_protocol_field = F("protocol.field")
   ```

2. **Create data collection function**:
   ```lua
   local function collect_protocol_stats()
     local stats = {}
     local tap = Listener.new("protocol", nil)
     
     function tap.packet(pinfo, tvb)
       local field_val = f2s(f_protocol_field)
       if field_val then
         stats[field_val] = (stats[field_val] or 0) + 1
       end
     end
     
     retap_packets()
     tap:remove()
     return stats
   end
   ```

3. **Add to report generator**:
   - Call collection function
   - Convert to sorted array: `dict_to_sorted_array(stats, 10)`
   - Generate chart: `generate_bar_chart(data, "Title", x, y, w, h, show_legend)`
   - Update section numbering

4. **Update TOC** if adding to detailed report

### Adding a New Chart Type

Follow the SVG generation pattern and color scheme (10-color palette defined in chart functions). Use `xml_escape()` for all text content.

## Testing Requirements

Always test with:
- Wireshark sample captures from https://wiki.wireshark.org/SampleCaptures
- Empty captures
- Large captures (10K+ packets)
- Various protocols
- Applied display filters

Check Wireshark Lua console (View → Internals → Lua) for any errors.

## Platform-Specific Notes

### macOS
- Plugin directory: `~/.local/lib/wireshark/plugins/`
- Use Homebrew for dependencies: `brew install librsvg poppler`
- Wireshark from DMG or Homebrew cask

### Linux
- Plugin directory: `~/.local/lib/wireshark/plugins/`
- Package managers vary by distro (apt, dnf, pacman)
- Check PLATFORM_PREREQUISITES.md for distro-specific instructions

### Windows
- Plugin directory: `%APPDATA%\\Wireshark\\plugins\\`
- PowerShell installer: `installers/windows/install.ps1`
- External tools must be in system PATH
- Console windows may flash during PDF generation (expected behavior)
- See WINDOWS_CONSOLE_FIX.md for details

## Version & Status

- Current version: 0.2.3 (public beta)
- Status: Functional but not production-ready
- License: GPL v2
- Repository: https://github.com/netwho/PacketReporter

## Documentation Files

- `README.md` - Complete user guide
- `QUICKSTART.md` - 5-minute getting started
- `PROJECT_OVERVIEW.md` - Technical architecture details
- `CONTRIBUTING.md` - Contribution guidelines
- `PLATFORM_PREREQUISITES.md` - Platform-specific dependency info
- `COVER_PAGE_IMPLEMENTATION.md` - Cover page system details
- `CHANGELOG.md` - Version history
