# v0.2.4 Release

## 🎯 What's New

**Enhanced TLS/SSL Detection**
- Completely rewritten TLS version detection for improved accuracy
- Now correctly identifies TLS 1.3 using `supported_versions` extension
- Fixed false TLS 1.2 reporting for TLS 1.3 connections
- Improved QUIC protocol detection

**Better User Experience**
- Streamlined dependency reporting (only shows when something is missing)
- Improved chart display with better label positioning
- Removed debug code for cleaner operation

## 🔧 Technical Improvements

- TLS detection now prioritizes `supported_versions` extension → cipher suite → protocol string
- Only counts handshake packets to avoid false positives
- Dependency checks prevent PDF export if required tools are missing

See [CHANGELOG.md](CHANGELOG.md) for complete details.

